package one.only.player.feature.player.ui.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SliderState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.time.Duration.Companion.milliseconds
import one.only.player.core.model.PlayerControl
import one.only.player.feature.player.LocalControlsVisibilityState
import one.only.player.feature.player.extensions.formatted
import one.only.player.feature.player.extensions.noRippleClickable
import one.only.player.feature.player.state.MediaPresentationState
import one.only.player.feature.player.state.durationFormatted
import one.only.player.feature.player.ui.MenuRoute
import one.only.player.feature.player.ui.PlayerControlBinding
import top.yukonga.miuix.kmp.basic.Text as MiuixText
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
internal fun ControlsBottomModernView(
    modifier: Modifier = Modifier,
    mediaPresentationState: MediaPresentationState,
    pendingSeekPosition: Long?,
    bottomLeftControls: List<PlayerControl>,
    bottomRightControls: List<PlayerControl>,
    bindings: Map<PlayerControl, PlayerControlBinding>,
    maxVisibleLeftControls: Int,
    maxVisibleControls: Int,
    onOpenPanel: (MenuRoute) -> Unit,
    onSeek: (Long) -> Unit,
    onSeekEnd: () -> Unit,
) {
    val systemBarsPadding = WindowInsets.systemBars.union(WindowInsets.displayCutout).asPaddingValues()
    val controlsVisibilityState = LocalControlsVisibilityState.current
    val displayedPosition = pendingSeekPosition ?: mediaPresentationState.position
    val displayedPendingPosition = (mediaPresentationState.duration - displayedPosition).coerceAtLeast(0L)
    Column(
        modifier = modifier
            .padding(systemBarsPadding)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        ModernSeekbar(
            modifier = Modifier.padding(
                playerProgressHorizontalPadding(
                    containerHorizontalPadding = 8.dp,
                    trackEdgeInset = 7.dp,
                ),
            ),
            position = displayedPosition.toFloat(),
            duration = mediaPresentationState.duration.toFloat(),
            onSeek = {
                controlsVisibilityState?.showControls()
                onSeek(it.toLong())
            },
            onSeekFinished = { onSeekEnd() },
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PlayerCornerControls(
                controls = bottomLeftControls,
                bindings = bindings,
                maxVisibleControls = maxVisibleLeftControls,
                onOpenPanel = onOpenPanel,
            )
            var shouldShowPendingPosition by rememberSaveable { mutableStateOf(false) }
            val positionText = when (shouldShowPendingPosition) {
                true -> "-${displayedPendingPosition.milliseconds.formatted()}"
                false -> displayedPosition.milliseconds.formatted()
            }
            Column(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .noRippleClickable {
                        shouldShowPendingPosition = !shouldShowPendingPosition
                    },
                verticalArrangement = Arrangement.Center,
            ) {
                MiuixText(
                    text = positionText,
                    style = MiuixTheme.textStyles.footnote1,
                    color = Color.White,
                    maxLines = 1,
                )
                MiuixText(
                    text = mediaPresentationState.durationFormatted,
                    style = MiuixTheme.textStyles.footnote1,
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 1,
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            PlayerCornerControls(
                controls = bottomRightControls,
                bindings = bindings,
                maxVisibleControls = maxVisibleControls,
                onOpenPanel = onOpenPanel,
            )
        }
    }
}

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModernSeekbar(
    modifier: Modifier = Modifier,
    position: Float,
    duration: Float,
    onSeek: (Float) -> Unit,
    onSeekFinished: () -> Unit,
) {
    val accentColor = MaterialTheme.colorScheme.primary
    val valueRange = 0f..duration.coerceAtLeast(0f)
    val sliderState = remember(valueRange) { SliderState(trackRange = valueRange) }

    // 播放进度推进时同步外部位置；拖动中 onValueChange 已把最新值写回 position，同值赋值无跳变
    sliderState.value = position.coerceIn(valueRange)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Slider(
            state = sliderState,
            modifier = modifier
                .fillMaxWidth()
                .testTag("seekbar_modern"),
            onValueChange = onSeek,
            onValueChangeFinished = onSeekFinished,
            thumb = {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .border(2.dp, Color.White, CircleShape)
                        .padding(2.dp)
                        .clip(CircleShape)
                        .background(accentColor),
                )
            },
            track = { state ->
                SliderDefaults.Track(
                    sliderState = state,
                    modifier = Modifier.height(4.dp),
                    colors = SliderDefaults.colors(
                        activeTrackColor = accentColor,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f),
                    ),
                    thumbTrackGapSize = 0.dp,
                    drawStopIndicator = null,
                )
            },
        )
    }
}
